M.Z BRAND — FREE HOSTING & PAYMENT SETUP
==========================================

FILES
-----
index.html   Main website
styles.css   Responsive design
script.js    Store interactions and WhatsApp contact
README.txt  This guide

1) FREE HOSTING WITH GITHUB PAGES (static site)
------------------------------------------------
A. Create/sign in to a GitHub account at https://github.com/
B. Create a new PUBLIC repository named mz-brand (or another name).
C. Upload index.html, styles.css, and script.js to the repository root.
D. Open Settings > Pages.
E. Under Build and deployment, choose "Deploy from a branch".
F. Select branch "main" and folder "/ (root)", then Save.
G. Wait for GitHub Pages to publish. The site URL will be shown in Settings > Pages,
   usually https://YOUR-USERNAME.github.io/mz-brand/

Important: This is static hosting. It does not provide secure user accounts,
a database, order management, or payment processing by itself.

2) WHATSAPP
-----------
The website has been configured to open WhatsApp for:
+92 324 9211348
Test the button after publishing. The number must have an active WhatsApp account.
For privacy, do not put passwords or payment PINs in WhatsApp messages.

3) JAZZCASH / EASYPAISA PAYMENTS
--------------------------------
Real online payments require a merchant account and official payment gateway
credentials/API integration. Do not put secret keys in script.js or any browser
code. Do not ask customers to send PINs or OTPs.

Practical launch choices:
- Fastest first launch: add Cash on Delivery and/or manual bank/mobile-wallet
  instructions, then confirm orders manually. Clearly label manual payment as
  pending verification and never claim an automated payment has succeeded.
- Automated online payments: contact JazzCash and/or Easypaisa for a merchant
  account and current e-commerce gateway integration documentation. A secure
  server/backend must create payment requests and verify callbacks/webhooks.
  Credentials must be stored as server-side environment variables.
- Before going live, test using the provider's official sandbox/test mode and
  confirm successful, failed, cancelled, and duplicate payment cases.

4) LOGIN / SIGNUP
-----------------
The current login/signup is a demo interface only. Do not use it for real users
until you connect a secure authentication service/backend. No password is saved.

5) BEFORE PUBLIC LAUNCH
-----------------------
[ ] Replace demo products, descriptions, and prices with real products.
[ ] Add your business address/contact and shipping/return/privacy policies.
[ ] Test the website on a phone and computer.
[ ] Verify the WhatsApp number.
[ ] Decide shipping fees and delivery areas.
[ ] Add a secure order database and payment backend if accepting online payments.
[ ] Test checkout end-to-end before accepting customer money.

This package does not automatically publish the website or create a payment merchant
account. You must complete hosting and payment-provider onboarding steps yourself.
