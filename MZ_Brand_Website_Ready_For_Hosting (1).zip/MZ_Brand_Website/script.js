// M.Z Brand demo storefront. Replace demo data and connect a secure backend before launch.
const products = [
  {id:1,name:"Everyday Essential",category:"THE DAILY EDIT",price:2499,color:"#9ba58b",tag:"BESTSELLER"},
  {id:2,name:"Studio Classic",category:"M.Z SIGNATURE",price:3199,color:"#b7a18c",tag:"NEW DROP"},
  {id:3,name:"Weekend Form",category:"OFF-DUTY STYLE",price:2799,color:"#8e9ca4",tag:"LIMITED"},
  {id:4,name:"Minimal Carry",category:"EVERYDAY OBJECTS",price:1899,color:"#b8a8ba",tag:"POPULAR"},
  {id:5,name:"Core Collection",category:"THE ESSENTIALS",price:3499,color:"#c6b878",tag:"NEW"},
  {id:6,name:"The M.Z Edit",category:"STUDIO PICKS",price:2299,color:"#9faaa0",tag:"STAFF PICK"}
];
let cart = [];
let accountMode = "login";
const $ = (id) => document.getElementById(id);
const formatPrice = n => "Rs. " + n.toLocaleString("en-PK");
function showToast(message){const t=$("toast");t.textContent=message;t.classList.add("show");clearTimeout(showToast.timer);showToast.timer=setTimeout(()=>t.classList.remove("show"),2600)}
function renderProducts(){
  $("productGrid").innerHTML=products.map(p=>`
    <article class="product-card">
      <div class="product-art" style="--shape:${p.color}">
        <span class="product-tag">${p.tag}</span><div class="shape" aria-hidden="true"></div>
        <button class="add-btn" data-add="${p.id}" aria-label="Add ${p.name} to bag">+</button>
      </div>
      <div class="product-info"><div><h3>${p.name}</h3><p>${p.category}</p></div><span class="product-price">${formatPrice(p.price)}</span></div>
    </article>`).join("");
}
function addToCart(id){const p=products.find(x=>x.id===id);const found=cart.find(x=>x.id===id);if(found)found.qty++;else cart.push({...p,qty:1});renderCart();showToast(`${p.name} added to your bag`)}
function renderCart(){
  $("cartCount").textContent=cart.reduce((sum,p)=>sum+p.qty,0);
  $("cartItems").innerHTML=cart.length?cart.map(p=>`<div class="cart-line"><span>${p.name} × ${p.qty}</span><strong>${formatPrice(p.price*p.qty)}</strong><button data-remove="${p.id}" aria-label="Remove ${p.name}">Remove</button></div>`).join(""):'<p>Your bag is empty. Find something you love in the collection.</p>';
  $("cartTotal").textContent=formatPrice(cart.reduce((sum,p)=>sum+p.price*p.qty,0));
}
function openModal(id){$(id).hidden=false;document.body.style.overflow="hidden"}
function closeModal(id){$(id).hidden=true;document.body.style.overflow=""}
function setAccountMode(mode){
  accountMode=mode;
  document.querySelectorAll(".tab").forEach(b=>b.classList.toggle("active",b.dataset.tab===mode));
  $("accountName").hidden=mode!=="signup";$("nameLabel").hidden=mode!=="signup";
  $("accountName").required=mode==="signup";
  $("accountPassword").autocomplete=mode==="signup"?"new-password":"current-password";
  $("accountSubmit").textContent=mode==="signup"?"Create account":"Sign in";
  $("accountMessage").textContent="";
}
document.addEventListener("click",e=>{
  const add=e.target.closest("[data-add]");if(add)addToCart(Number(add.dataset.add));
  const remove=e.target.closest("[data-remove]");if(remove){cart=cart.filter(p=>p.id!==Number(remove.dataset.remove));renderCart()}
  const close=e.target.closest("[data-close]");if(close)closeModal(close.dataset.close);
  const tab=e.target.closest("[data-tab]");if(tab)setAccountMode(tab.dataset.tab);
});
$("menuToggle").addEventListener("click",()=>{const open=$("mainNav").classList.toggle("open");$("menuToggle").setAttribute("aria-expanded",String(open));$("menuToggle").textContent=open?"×":"☰"});
$("mainNav").addEventListener("click",e=>{if(e.target.closest("a")){$("mainNav").classList.remove("open");$("menuToggle").setAttribute("aria-expanded","false");$("menuToggle").textContent="☰"}});
$("accountBtn").addEventListener("click",()=>openModal("accountModal"));
$("cartBtn").addEventListener("click",()=>{renderCart();openModal("cartModal")});
document.querySelectorAll(".modal-backdrop").forEach(backdrop=>backdrop.addEventListener("click",e=>{if(e.target===backdrop)closeModal(backdrop.id)}));
document.addEventListener("keydown",e=>{if(e.key==="Escape")document.querySelectorAll(".modal-backdrop:not([hidden])").forEach(m=>closeModal(m.id))});
$("accountForm").addEventListener("submit",e=>{
  e.preventDefault();
  // Demo-only: never store passwords in localStorage or claim real authentication.
  $("accountMessage").textContent=accountMode==="signup"
    ?"Demo only: account creation needs a secure server to finish. No account was created."
    :"Demo only: sign-in needs a secure server. No login was performed.";
});
$("checkoutBtn").addEventListener("click",()=>{
  if(!cart.length){showToast("Your bag is empty");return}
  showToast("Checkout is a demo. Add a payment provider to accept payments.");
});
$("newsletterForm").addEventListener("submit",e=>{e.preventDefault();showToast("Thanks! Newsletter signup needs a connected email service.");e.target.reset()});
$("year").textContent=new Date().getFullYear();
// IMPORTANT: replace this placeholder with the business's real WhatsApp number in international format.
const WHATSAPP_NUMBER="923249211348";
$("whatsappLink").href=`https://wa.me/${WHATSAPP_NUMBER}?text=${encodeURIComponent("Assalam-o-alaikum, I am interested in M.Z Brand.")}`;
renderProducts();renderCart();
